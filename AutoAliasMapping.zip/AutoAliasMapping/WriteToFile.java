package com.sap.businessobjects.jeremyma;


import java.io.*;

import java.util.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.framework.IEnterpriseSession;
import com.crystaldecisions.sdk.plugin.desktop.program.IProgramBase;
import com.crystaldecisions.sdk.occa.infostore.IInfoStore;

public class WriteToFile implements IProgramBase  {

	/**
	 * @param args
	 * @throws SDKException 
	 * @throws IOException 
	 */
	 public static void main(String[] args) 
	 			throws java.lang.InterruptedException {
		//java.net.URL CleansingRISE_log4j = ClassLoader.getSystemResource("CleansingRISE_log4j.properties");
		//PropertyConfigurator.configure(CleansingRISE_log4j);
		
		//logger.info("Starting - in main");
		System.out.println("TEST");
		
		//WriteToFile wtf = new WriteToFile();
		
		String numMinute = args[0]; // number of hours to run for 
		if (numMinute == null) numMinute ="1";
		
		String path = args[1];	// location of the file
		if ( path == null ) path = "C://temp/writeToFile.txt";
		long systemCurr = System.currentTimeMillis()/1000;  // get the current time in seconds
		
		int numSec = (int) systemCurr + Integer.parseInt(numMinute.trim())*60;
		int freq = Integer.parseInt(args[2].trim()) * 1000;
		System.out.println (freq);
	

        while (numSec >=  systemCurr )
        {
        	systemCurr = System.currentTimeMillis()/1000;;
            try{
        		BufferedWriter myOutput = writeTabDelimitedFile(path);
        		String txtToWrite = getDateTime().toString();
        		myOutput.append( txtToWrite );
        		myOutput.newLine();
        		myOutput.flush();
        		myOutput.close();
            } catch (Exception e1) {
            	System.out.println("Error: " + getDateTime().toString());
            	e1.printStackTrace();
            
    	}

        		Thread.sleep(freq); // sleep and wait by certina time
        		
        }
        //myOutput.close();
        System.out.println("done!");
        	

		//logger.info("Ended");
	}
	 public void runNow(int numSec, long  systemCurr, int freq, String path)
	 {
	        while (numSec >=  systemCurr )
	        {
	        	systemCurr = System.currentTimeMillis()/1000;;
	            try{
	        		BufferedWriter myOutput = writeTabDelimitedFile(path);
	        		String txtToWrite = getDateTime().toString();
	        		myOutput.append( txtToWrite );
	        		myOutput.newLine();
	        		myOutput.flush();
	        		myOutput.close();
	            } catch (Exception e1) {
	            	System.out.println("Error: " + getDateTime().toString());
	            	e1.printStackTrace();
	            
	    	}
	            try
	            {
	            	Thread.sleep(freq); // sleep and wait by certina time
	            	
	            }
	            catch (Exception e2) {
	            	System.out.println("Error: " + getDateTime().toString());
	            	e2.printStackTrace();
	            }
	        		
	        }
	 }
	 
	public void run(IEnterpriseSession Session, IInfoStore InfoStore, String[] args) throws SDKException 
	 {
		//java.net.URL CleansingRISE_log4j = ClassLoader.getSystemResource("CleansingRISE_log4j.properties");
		//PropertyConfigurator.configure(CleansingRISE_log4j);
		
		//logger.info("Starting - in main");
		
		System.out.println("Running");
		WriteToFile wtf = new WriteToFile();
		//WriteToFile wtf = new WriteToFile();
		
		String numMinute = args[0]; // number of hours to run for 
		if (numMinute == null) numMinute ="1";
		
		String path = args[1];	// location of the file
		if ( path == null ) path = "C://temp/writeToFile.txt";
		long systemCurr = System.currentTimeMillis()/1000;  // get the current time in seconds
		
		int numSec = (int) systemCurr + Integer.parseInt(numMinute.trim())*60;
		int freq = Integer.parseInt(args[2].trim()) * 1000;
		System.out.println (freq);
		wtf.runNow(numSec, systemCurr, freq, path);
	


        //myOutput.close();
        System.out.println("done!");
        	

		//logger.info("Ended");
		 
	 }


		    /**
	       * Method to read tab delimited  file
	       */
		public static BufferedWriter writeTabDelimitedFile(String filePath){
			  String fName = filePath;	
			  BufferedWriter myOutput = null;
			  try{
				  FileWriter fws = new FileWriter(fName,true);
				  myOutput = new BufferedWriter(fws);
			  }catch (IOException e) {
		
		         e.printStackTrace();
		     }
			  return myOutput;
		}



	    private static String getDateTime() {
	        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	        Date date = new Date();
	        return dateFormat.format(date);
	    }

	       /**
	        * 
	        */
	       public WriteToFile() {

	           try {
	        	   Class.forName("1").newInstance();

	           } catch (ClassNotFoundException e) {
	               e.printStackTrace();
	           } catch (InstantiationException e) {
	               e.printStackTrace();
	           } catch (IllegalAccessException e) {
	               e.printStackTrace();
	           } 
	           

	       }


}
