package com.sap.businessobjects.jeremyma;

import java.util.Hashtable;


import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

public class LDAPQuery {

	public static String getAttribue (HttpServletRequest request){
		
		String PROVIDER_URL = request.getSession().getServletContext().getInitParameter("PROVIDER_URL"); 
		String SECURITY_AUTHENTICATION = request.getSession().getServletContext().getInitParameter("SECURITY_AUTHENTICATION"); 
		String SECURITY_PRINCIPAL = request.getSession().getServletContext().getInitParameter("SECURITY_PRINCIPAL"); 
		String SECURITY_CREDENTIALS = request.getSession().getServletContext().getInitParameter("SECURITY_CREDENTIALS"); 
		String LDAP_ATTRIBUTE = request.getSession().getServletContext().getInitParameter("LDAP_ATTRIBUTE"); 
		
		String stringAttribute ="";
		Hashtable env = new Hashtable();
		
		env.put(Context.INITIAL_CONTEXT_FACTORY,
				"com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, PROVIDER_URL);
		env.put(Context.SECURITY_AUTHENTICATION, SECURITY_AUTHENTICATION);
		env.put(Context.SECURITY_PRINCIPAL, SECURITY_PRINCIPAL);
		env.put(Context.SECURITY_CREDENTIALS, SECURITY_CREDENTIALS);
		
		DirContext ctx = null;
		NamingEnumeration results = null;
		try {
			ctx = new InitialDirContext(env);
			SearchControls controls = new SearchControls();
			controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			results = ctx.search("", "(uid=CONSULTANT)", controls);
			while (results.hasMore()) {
				SearchResult searchResult = (SearchResult) results.next();
				Attributes attributes = searchResult.getAttributes();
				Attribute attr = attributes.get(LDAP_ATTRIBUTE);
				stringAttribute = (String) attr.get();
				System.out.println(" " + stringAttribute );

			}
		} catch (NamingException e) {
			throw new RuntimeException(e);
		} finally {
			if (results != null) {
				try {
					results.close();
				} catch (Exception e) {
				}
			}
			if (ctx != null) {
				try {
					ctx.close();
				} catch (Exception e) {
				}
			}
		}
		return stringAttribute;
	}
	
	
	public static void main(String[] args) {
		//System.out.println(getAttribue());
		
	}
	
}