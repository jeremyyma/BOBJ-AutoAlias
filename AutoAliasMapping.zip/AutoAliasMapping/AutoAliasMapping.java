/**
 * @author Jeremy.Ma@sap.com 5/26/2012
 * The purpose of this batch process Map user's SAP Aliases from Windows LDAP\AD 
 * 
 * This software is the confidential and proprietary information
 * of SAP AG and its affiliates. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with SAP AG.
 * 
 * LIMITATIONS OF WARRANTIES AND LIABILITY: THIS SOFTWARE IS PROVIDED AND LICENSED BY SAP S ON AN "AS IS" BASIS, WITHOUT ANY OTHER WARRANTIES OR CONDITIONS, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABLE QUALITY, SATISFACTORY QUALITY, MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THOSE ARISING BY LAW, STATUTE, USAGE OF TRADE, COURSE OF DEALING OR OTHERWISE. THE ENTIRE RISK AS TO THE RESULTS AND PERFORMANCE OF THE SOFTWARE IS ASSUMED BY YOU. NEITHER BUSINESS OBJECTS NOR ITS DEALERS OR SUPPLIERS SHALL HAVE ANY LIABILITY TO YOU OR ANY OTHER PERSON OR ENTITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES WHATSOEVER, INCLUDING, BUT NOT LIMITED TO, LOSS OF REVENUE OR PROFIT, LOST OR DAMAGED DATA OR OTHER COMMERCIAL OR ECONOMIC LOSS, EVEN IF BUSINESS OBJECTS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, OR THEY ARE FORESEEABLE. BUSINESS OBJECTS IS ALSO NOT RESPONSIBLE FOR CLAIMS BY A THIRD PARTY THAT THE SOFTWARE INFRINGES THE THIRD PARTY'S COPYRIGHT, PATENT OR OTHER INTELLECTUAL PROPERTY. THE LIMITATIONS SET FORTH HEREIN SHALL APPLY WHETHER OR NOT THE ALLEGED BREACH OR DEFAULT IS A BREACH OF A FUNDAMENTAL CONDITION OR TERM OR A FUNDAMENTAL BREACH. SOME STATES/COUNTRIES DO NOT ALLOW THE EXCLUSION OR LIMITATION OF IMPLIED WARRANTIES OR OF LIABILITY FOR CONSEQUENTIAL OR INCIDENTAL DAMAGES, SO THE ABOVE LIMITATIONS MAY NOT APPLY TO YOU. 
 */
package com.sap.businessobjects.jeremyma;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.framework.CrystalEnterprise;
import com.crystaldecisions.sdk.framework.IEnterpriseSession;
import com.crystaldecisions.sdk.framework.ISessionMgr;
import com.crystaldecisions.sdk.occa.infostore.IInfoObjects;
import com.crystaldecisions.sdk.occa.infostore.IInfoStore;
import com.crystaldecisions.sdk.plugin.desktop.program.IProgramBase;
import com.crystaldecisions.sdk.plugin.desktop.user.IUser;
import com.crystaldecisions.sdk.plugin.desktop.user.IUserAlias;
import com.crystaldecisions.sdk.plugin.desktop.user.IUserAliases;

public class AutoAliasMapping implements IProgramBase
{
	static Logger logger = Logger.getLogger(AutoAliasMapping.class.getName());
	
	private static IInfoStore _infoStore = null;
	private static IInfoStore queryAliasIStor = null;
	private IEnterpriseSession eSession;
	static String strUserGroupList[];
	static int intUserGroupIDList[];
	static BufferedReader inputFile;
	static BufferedWriter loggingFileName;  //record action record alias assign
	static HashMap	userAliasContainerItems = new HashMap();
	IInfoObjects userQuery;

	// runtime CMS information variables from AutoAliasMapping.properties file
	private String _cmsHost, _cmsUser, _cmsPassword, _cmsAuthType;
	private String _ldapURL, _ldapUser, _ldapPass, _targetMappingAuth, _sourceMappingAuth, _ldapSearchAttribute, _ldapReturnAttribute, 
	_searchLDAPsubString, _runInProdMode, _updateSinceHours, _exceptionFileName,_cmsSearchExactMatch, _ldapSearchExactMatch,_ldapReferral;
	
	
	Hashtable  ldapEnv = new Hashtable();
	DirContext ctx = null;

	void init(IInfoStore infoStore) throws Exception {
		
		logger.info("AutoAliasMapping code: 1.07");
		
		InputStream propsFile = ClassLoader.getSystemResourceAsStream("AutoAliasMapping.properties");
		Properties props = new Properties(); //runtime properties
		try {
			props.load(propsFile);
		} catch (IOException io) {
			logger.error("error loading the AutoAliasMapping.properities file!! ",
					io);
			throw io;
		}	
		/**
		 * Load the CMS variables from the property file
		 */
		
		_cmsHost = props.getProperty("cmsHost");
		if (_cmsHost == null) {
			logger.error("Property 'cmsHost' not specified!");
			throw new Exception("Property 'cmsHost' not specified!");
		}

		_cmsUser = props.getProperty("cmsUser");
		if (_cmsUser == null) {
			logger.error("Property 'cmsUser' not specified!");
			throw new Exception("Property 'cmsUser' not specified!");
		}

		_cmsPassword = props.getProperty("cmsPassword");
		if (_cmsPassword == null) _cmsPassword = System.getProperty("cmsPassword");
		if (_cmsPassword == null) {
			logger.error("Property 'cmsPassword' not specified!");
			throw new Exception("Property 'cmsPassword' not specified!");
		}

		_cmsAuthType = props.getProperty("cmsAuthType");
		if (_cmsAuthType == null) {
			logger.error("Property 'cmsAuthType' not specified!");
			throw new Exception("Property 'cmsAuthType' not specified!");
		}
		
		_ldapURL = props.getProperty("ldapURL");
		if (_ldapURL == null) {
			logger.error("Property 'ldapURL' not specified!");
			throw new Exception("Property 'ldapURL' not specified!");
		}
		logger.info("ldapURL: " + _ldapURL);
		
		_ldapUser = props.getProperty("ldapUser");
		if (_ldapUser == null) {
			logger.error("Property 'ldapUser' not specified!");
			throw new Exception("Property 'ldapUser' not specified!");
		}
		logger.info("ldapUser name: " + _ldapUser);
		
		_ldapPass = props.getProperty("ldapPass");
		if (_ldapPass == null) _ldapPass = System.getProperty("ldapPass");
		if (_ldapPass == null) {
			logger.error("Property 'ldapPass' not specified!");
			throw new Exception("Property 'ldapPass' not specified!");
		}
		logger.info("ldapPass : xxxxxxxx");
		
		_targetMappingAuth = props.getProperty("tagetMappingAuth");
		if (_ldapPass == null) {
			logger.error("Property 'tagetMappingAuth' not specified!");
			throw new Exception("Property 'tagetMappingAuth' not specified!");
		}
		logger.info("tagetMappingAuth name: " + _targetMappingAuth);
		
		_sourceMappingAuth = props.getProperty("sourceMappingAuth");
		if (_ldapPass == null) {
			logger.error("Property 'sourceMappingAuth' not specified!");
			throw new Exception("Property 'sourceMappingAuth' not specified!");
		}
		
		logger.info("sourceMappingAuth name: " + _sourceMappingAuth);

		_ldapReturnAttribute = props.getProperty("ldapReturnAttribute");
		if (_ldapReturnAttribute == null) {
			logger.error("Property 'ldapReturnAttribute' not specified!");
			throw new Exception("Property 'ldapReturnAttribute' not specified!");
		}
		logger.info("ldapReturnAttribute name: " + _ldapReturnAttribute);
		
		
		_ldapSearchAttribute = props.getProperty("ldapSearchAttribute");
		if (_ldapSearchAttribute == null) {
			logger.error("Property 'ldapSearchAttribute' not specified!");
			throw new Exception("Property 'ldapSearchAttribute' not specified!");
		}
		logger.info("ldapSearchAttribute name: " + _ldapSearchAttribute);
	   
		/*
	   	String sourceFN = props.getProperty("sourceFileName");
		if (sourceFN == null) {
			logger.error("Property 'sourceFileName' not specified!");
			throw new Exception("Property 'sourceFileName' not specified!");
		}*/

	   	
	   	_runInProdMode = props.getProperty("runInProdMode");
		if (_runInProdMode == null) {
			logger.error("Property 'runInProdMode' not specified!");
			throw new Exception("Property 'runInProdMode' not specified!");
		}
		logger.info("Running in Prodmode (commit CMS): " + _runInProdMode); 
	   		
		_updateSinceHours = props.getProperty("updateSinceHours");
		if (_updateSinceHours == null) {
			logger.error("Property 'updateSinceHours' not specified!");
			throw new Exception("Property 'updateSinceHours' not specified!");
		}
		logger.info("updateSinceHours: " + _updateSinceHours); 
		   
		
		_exceptionFileName = props.getProperty("exceptionFileName");
		if (_exceptionFileName == null) {
			logger.error("Property 'exceptionFileName' not specified!");
			throw new Exception("Property 'exceptionFileName' not specified!");
		}
		
		
		_cmsSearchExactMatch = props.getProperty("cmsSearchExactMatch");
		if (_cmsSearchExactMatch == null) {
			logger.error("Property 'cmsSearchExactMatch' not specified!");
			throw new Exception("Property 'cmsSearchExactMatch' not specified!");
		}
		logger.info("Running with cmsSearchExactMatch: " + _cmsSearchExactMatch); 
		
		_ldapSearchExactMatch = props.getProperty("ldapSearchExactMatch");
		if (_ldapSearchExactMatch == null) {
			_ldapSearchExactMatch="true";
			logger.info("Property 'ldapSearchExactMatch' not specified! Use Default _ldapSearchExactMatch=true ");
		}
		
		logger.info("ldapSearchExactMatch: " + _ldapSearchExactMatch); 
		
		_searchLDAPsubString = props.getProperty("searchLDAPsubString");
		if (_searchLDAPsubString == null) {
			logger.error("Property 'searchLDAPsubString' not specified!");
			throw new Exception("Property 'searchLDAPsubString' not specified!");
		}
		
		_ldapReferral = props.getProperty("ldapReferral");
		if (_searchLDAPsubString == null) {
			logger.info("Property 'searchLDAPsubString' not specified!");
			_ldapReferral="ignore";
		}
		
//	   	inputFile 	= com.zurich.BOETools.Util.getTabDelimitedFile (sourceFN);
	   	loggingFileName = writeLogFile(_exceptionFileName);
	   
		if (infoStore == null) {
			// create a new session to the CMS database
			logger.info("Logging into the CMS database");
			login();
		}
		else {
			// There is already a valid CMS session
			AutoAliasMapping._infoStore = infoStore;
		}
		
		ldapEnv.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
		ldapEnv.put(Context.PROVIDER_URL, _ldapURL);
		ldapEnv.put(Context.SECURITY_AUTHENTICATION, "simple");
		ldapEnv.put(Context.SECURITY_PRINCIPAL, _ldapUser);
		ldapEnv.put(Context.SECURITY_CREDENTIALS, _ldapPass);
		ldapEnv.put( Context.REFERRAL, _ldapReferral);
		
		openLDAP (ldapEnv);
		
	}
    /**
     * Method to write log  file
     */
		public static BufferedWriter writeLogFile(String outputFileName){
			  String fName = outputFileName;	
			  BufferedWriter myOutput = null;
			  try{
				  FileWriter fws = new FileWriter(fName,true);
				  myOutput = new BufferedWriter(fws);
			  }catch (IOException e) {
		
		         e.printStackTrace();
		     }
			  return myOutput;
		}
	/**
	 * open LDAP Server connects
	 */
	
	void openLDAP(Hashtable<String,String> ldapEnv)
	{
		try{
			ctx = new InitialDirContext(ldapEnv);
		}	catch (NamingException e) {
			throw new RuntimeException(e);
		} 
	}
	/**
	 * Query the LDAP Server for by 
	 * _ldapSearchAttribute (UID\employeeID)
	 * return the _ldapReturnAttribute value
	 */
	private String queryLDAP(String searchText, boolean exactMatch)
	{
		logger.debug("calling queryLDAP: " + searchText + "," + exactMatch);
		
		NamingEnumeration ldapResults = null;
		String results = "";
		String searchFilter ="";
		if (exactMatch)
		{
			searchFilter = "(" + _ldapSearchAttribute + "=" + searchText + ")";   //"(uid=CONSULTANT)
		}
		else
		{
			searchFilter = "(" + _ldapSearchAttribute + "=*" + searchText + ")";   //"(uid=CONSULTANT)
		}
		try {
			ctx = new InitialDirContext(ldapEnv);
			SearchControls controls = new SearchControls();
			controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			//controls.setDerefLinkFlag(false);  //
			ldapResults = ctx.search("", searchFilter, controls);
			logger.debug("queryLDAP filters: " + searchFilter);
			while (ldapResults.hasMore()) {
				SearchResult searchResult = (SearchResult) ldapResults.next();
				Attributes attributes = searchResult.getAttributes();
				Attribute attr = attributes.get(_ldapReturnAttribute);
				if (attr != null)
					results = attr.get().toString();
				logger.debug("LDAP Search Results for " + searchText + " = " + results);

			}
		} catch (NamingException e) {
			System.out.println(e.toString());
			logger.error(e.toString());
			results = "";
			//throw new RuntimeException(e.getMessage());
		} finally {
			if (ldapResults != null) {
				try {
					ldapResults.close();
				} catch (Exception e) {
				}
			}
			if (ctx != null) {
				try {
					ctx.close();
				} catch (Exception e) {
				}
			}
		}

		return results;
	}
	
	/*@ fixStringReturn
	 * This is to work on appending leading 00 (zeros) for employee ID where to be 8 character in length
	 * 
	 */
	public static String fixStringReturn (String text)
	{
		/*
		if (text.length()>=8)
		{
			return text;
		}
		else
		{
			for (int count=0; count < text.length(); count ++)
			{
				text = "0" + text;
			}
			return text;
		}
		*/
		if (text.length()>6)
		{
			return text.substring((text.length() -6), text.length());
		}
		else
		{
			return text;
		}
			
		
	}
	public static String getDateTime(int minusHours) 
	{	
		minusHours = minusHours*(-1);

		String dt = "";  // Start date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
		Calendar c = Calendar.getInstance();
		try{
			c.setTime(c.getTime());
			c.add(Calendar.HOUR, minusHours);  // number of days to add
		}catch (Exception e) {
			logger.error ("Fail at getDateTime");
		}
		


		dt = sdf.format(c.getTime());  // dt is now the new date
		return dt;
		
	}
	/*
	 * searchSAPAliasWOAD - Generate a worklist by searching For SAP Alias where it contains no Associated target (WinAD) Alias
	 * 
	 */

	void searchSAPAliasWOAD()
	{
		int updateHours = Integer.parseInt(_updateSinceHours);
		
		
		ArrayList userAliasContainerDetail = new ArrayList();
		int counter = 0;  // couting the number of Alias that ned to be fix
		
		IInfoObjects oInfoObjects =null;
		try
		{
			String fromDate = getDateTime(updateHours);
			_infoStore = (IInfoStore)eSession .getService("InfoStore");
			String query = "SELECT top 50000 SI_ID, SI_NAME, SI_Aliases FROM CI_SYSTEMOBJS WHERE SI_PROGID='CrystalEnterprise.USER' AND SI_ID != 12 "
					+ " AND SI_UPDATE_TS > '" + fromDate + "'";
			logger.debug("searchSAPAliasWOAD() - querying CMS for worklist " +  query);
			oInfoObjects = _infoStore.query(query);
			
		}
		catch (Exception e) {
			logger.error ("Fail at searchSAPAliasWOAD");
		}
		
        for(Iterator iuser = oInfoObjects.iterator() ; iuser.hasNext() ; ) {  
		    boolean hasTarget = false;
		    boolean hasSource = false;
        	IUser oUser = (IUser) iuser.next();
            IUserAliases userAliases = oUser.getAliases();
 
		      //retrieve the user and aliases

		      IUserAliases oAliases = oUser.getAliases();
		      boolean aliasExists = false;
		      Iterator iter = oAliases.iterator();
		      String userName = oUser.getTitle();

		      String[] storage = new String[3]; //Storing user Alias details
		      String tempAliasName = ""; // storing Alias name exmaple BW7~800/CAMPMAN
		      int tempAliasID = 0; // storing Alias unique identifier 
		      
		      //loop for each alias per user
		      for (Iterator ialias = userAliases.iterator() ; ialias.hasNext(); ) {
                  IUserAlias userAlias = (IUserAlias) ialias.next(); 
                  String authentication;

                  authentication = userAlias.getAuthentication();

                  if (_targetMappingAuth.equals(authentication) || hasTarget) hasTarget = true;
                  if (_sourceMappingAuth.equals(authentication) || hasSource) hasSource = true;
                  tempAliasName = oUser.getTitle();
    		      tempAliasID = oUser.getID();
		      }
		      
		      
		      //collect list of user who has source (SAP) but no target (WinAD)  only perform work that is necessary; if account is already properly setup ignore
		      if (hasSource && !hasTarget)
		      {
		    	  logger.debug("searchSAPAliasWOAD found " + userName + " alias ID=" + tempAliasID + " hasSource=" + hasSource + " and hasTarget=" + hasTarget + "");
		    	  storage = new String[3]; 
		    	  storage [0] = userName;
		    	  storage [1] = Integer.toString(tempAliasID);  
		    	  storage [2] = tempAliasName;
		    	  userAliasContainerDetail.add(counter,storage);
		    	  userAliasContainerItems.put(userName, userAliasContainerDetail);
		    	  counter ++;		    	  
		      }
		      else
		      {
		    	  logger.debug("searchSAPAliasWOAD not found " + userName + "hasSource=" + hasSource + " and hasTarget=" + hasTarget + "");
		      }

		 }
		
	}
	
	/*@
	 * getAliasIDBy
	 * existingAliasName - search by an existing user
	 * authenticationType - matching aliasID by secWinAD, secSAPR3
	 */
	public String getAliasIDBy (IUser user, String authenticationType)
	{
		String aliasID = "";
		IUserAliases existingAlias =null;

		try
		{
			IUserAliases userAliases;
	        userAliases = user.getAliases();

	        //This to handle accounts with already multiple Aliases
	        for(Iterator ialias = userAliases.iterator() ; ialias.hasNext() ; ) {
	        	IUserAlias userAlias;
	        	String authentication;
	        	userAlias = (IUserAlias) ialias.next(); 
	            authentication = userAlias.getAuthentication();
	                    
	            //only if matching authentication is targeted
	            if (authenticationType.equals(authentication)) {
	                   	existingAlias = userAliases;
	                    aliasID = Integer.toString( user.getID() );
	            }
	        }
		}         		
		catch (Exception e) {
			logger.error ("Fail at getAliasIDBy");
		}
		return aliasID;
	}
	/*@
	 * getAliasIDBy
	 * existingAliasName - search by an existing user
	 * authenticationType - matching aliasID by secWinAD, secSAPR3
	 */
	public IUser getUserBy (String aliasName, String authType) throws SDKException, IOException
	{	boolean cmsSearchExactMatch = _cmsSearchExactMatch.equalsIgnoreCase("true");
		IUser user = null;
		IUserAliases existingAlias = null;
		String cmsQuery ="";
		int count =0;
		try
		{
			queryAliasIStor = (IInfoStore)eSession .getService("InfoStore");
			if (cmsSearchExactMatch)
			{
				cmsQuery = "SELECT SI_ID, SI_NAME, SI_Aliases FROM CI_SYSTEMOBJS WHERE SI_PROGID='CrystalEnterprise.USER' AND SI_Name = '" + aliasName + "'";
			}
			else
			{
				cmsQuery = "SELECT SI_ID, SI_NAME, SI_Aliases FROM CI_SYSTEMOBJS WHERE SI_PROGID='CrystalEnterprise.USER' AND SI_Name LIKE '%" + aliasName + "%'";
			}
			
			userQuery = queryAliasIStor.query(cmsQuery);
			int userQuerySize =userQuery.getResultSize();
			
			if (userQuerySize == 0) logger.debug("getUserBy() - returns no results " + cmsQuery);
			// loop through the resultset and determin if their are multiple search with same targetAuthType
			for(Iterator iuser = userQuery.iterator() ; iuser.hasNext() ; ) {  
				IUser temp = (IUser) iuser.next();
				existingAlias = (temp).getAliases();
				for(Iterator ialias = existingAlias.iterator() ; ialias.hasNext() ; ) {
					
		        	IUserAlias userAlias;
		        	userAlias = (IUserAlias) ialias.next(); 
		            if ( userAlias.getAuthentication().equals(authType) )
		            {
		            	user = temp;
		            	count = count +1;
		            }
				}
			}
		
			
			if ( count!=1 ) //??? only count if same alias type of _tagetMappingAuth
			{
				writeExceptionFileName("Matching Error in getUserBy ," + aliasName + "," + authType + "," + count + ",");
				logger.error("getAliasID() - aliasName return incorrect record count (" +  count + ") when searching by " + aliasName );
				return user;  //if matching show more then 1 records flag error???
				
				
			}
			//???user = (IUser) userQuery.get(0);			
		}
		catch (Exception e) {
			writeExceptionFileName("Matching Error in getUserBy ," + aliasName + "," + authType + "," + count + ",");
			logger.error ("getUserBy() - Fail at getAliasID - with cmsQuery=" + cmsQuery + " matching counts " + count);
			logger.error(e.getStackTrace() + e.getMessage());
		}
		return user;
	}
	/**
	 * @ readSourceFile()
	 * loads the tab delimited file into Hashmap for later process.  
	 * It builds the global variables to be use by dissociateBatch and applyOverloadBatch.  
	 * The hashMap contain (username, where table, where clause restriction) 
	 */
    void readSourceFile()
       {
    	   
	       String thisLine	= null;   
	       int counter = 0 ;
	       	
	       ArrayList userAliasContainerDetail = new ArrayList();
	           
	       String previousName = "";
	       String[] storage = new String[3];
	   		// check each line for each user
	       try{
	    	   int counter1 =0 ;
	        while ((thisLine = inputFile.readLine()) != null){
	  			 
	  			 String strar[] 	= 	thisLine.split("\t");
	  			 String userName 	= 	strar[0];
	  			 String table		=	strar[1];
	  			 String whereStmt	=	strar[2];
	  			 
	  			//reset 
	  			 if (!userName.equals(previousName))
	  			 {	 	 //reset array list 
	  				userAliasContainerDetail = new ArrayList();
	  				counter = 0;
	  			 }
	  			 storage = new String[3]; 
      			 storage [0] = userName;
      			 storage [1] = table;
      			 storage [2] = whereStmt;
      			 userAliasContainerDetail.add(counter,storage);
      			 userAliasContainerItems.put(userName, userAliasContainerDetail);
      			 counter ++;
      			 counter1 ++;
      			
	  			//set previous name to compare later
	  			previousName = userName;
	  		 //dissociateOverloadByUser(userName,unvObjs);
	  			
	  		 }
	        logger.info("userAliasContainerItems.size()   " + counter1);
	  		
	  	} catch (IOException e)
    	   {
	  		System.out.println (e.getMessage());
    	   }
		}
	private static void writeExceptionFileName(String error) throws IOException
	{
		loggingFileName.write("\n" + getDateTime(0) + ", " + error);
	}


	
	private void login() throws Exception {
		/**
		 * Creates a session with the CMS and retrieve the InfoStore
		 */
		try {
			ISessionMgr mySessionMgr = CrystalEnterprise.getSessionMgr();
			eSession = mySessionMgr.logon(_cmsUser, _cmsPassword, _cmsHost, _cmsAuthType);
			
			if (eSession == null) {
				logger.error("Failed to logon to CMS - The session is null");
				throw new Exception(
						"Failed to logon to CMS - The session is null");
			} else {
				logger.info("Opened CMS session to - Host: " + _cmsHost
						+ " user: " + _cmsUser + " Password: xxxxx" + _cmsPassword
						+ " authType: " + _cmsAuthType);
			}

			_infoStore = (IInfoStore) eSession.getService("InfoStore");
		
		} catch (SDKException sdkEx) {
			logger.error("Failed to connect to CMS", sdkEx);
			throw new Exception("Failed to connect to CMS", sdkEx);
		}
	}
	/**
	 * Log off BOE and nullify the infostore
	 * @throws Exception
	 */
	private void logoff() throws Exception {
		_infoStore = null;
		eSession.logoff();	// CMS sessiong logout
		//??inputFile.close();	// Matching source file close
		ctx.close();		// LDAP Logoff
		loggingFileName.close();
		
		
	}
	/*@
	 *  performDeleteAndAdd() - Performs the matching rules by Source Taget type of authentication type
	 *  
	 */
	
	private void performDeleteAndAdd() throws SDKException, IOException
	{
		boolean commitTrue = _runInProdMode.equalsIgnoreCase("true");
		
		for(Iterator itr = userAliasContainerItems.keySet().iterator(); itr.hasNext();){
			String sourceAliasName = (String)itr.next(); //get the source login
	  		String sourceAliasNameStripped = sourceAliasName.substring( sourceAliasName.indexOf("/")+1 , sourceAliasName.length() );  //strip out system name BWx~000/
	  		
	  		//incorporate searchLDAPsubString condition - allow user determine length of searech souce.
	  		int searchLDAPsubStringBeg = Integer.parseInt(_searchLDAPsubString.substring(0, _searchLDAPsubString.indexOf(",")));
	  		int searchLDAPsubStringEnd = Integer.parseInt(_searchLDAPsubString.substring(_searchLDAPsubString.indexOf(",")+1, _searchLDAPsubString.length() ));
	  		if (sourceAliasNameStripped.length() <= searchLDAPsubStringEnd) searchLDAPsubStringEnd = sourceAliasNameStripped.length();
	  		
	  		sourceAliasNameStripped = sourceAliasNameStripped.substring(searchLDAPsubStringBeg, searchLDAPsubStringEnd); 
	  		
	  		String targetUser = queryLDAP(sourceAliasNameStripped, true); // query LDAP server to get full name by employeeID = sapLoginID
  			// @ Kiewit, if user account does not match try it with leading 000 with meet 8 character length

	  		if (targetUser.length() <1 && !_ldapSearchExactMatch.equalsIgnoreCase("true"))  // search again in LDAP for right 6 character for kiweit only.
	  		{
	  			//targetUser = queryLDAP(fixStringReturn(sourceAliasNameStripped), false); // search again in LDAP for right 6 character for kiweit only.
	  			targetUser = queryLDAP(sourceAliasNameStripped, false); 
	  		}
	  		
	  		if (  targetUser.length()>2 )
	  		{
	  			logger.debug("performDeleteAndAdd() query LDAP Account to get " + _targetMappingAuth + " user " + targetUser  + " with "+  sourceAliasName);
	  			IUser existingSourceUser = getUserBy(sourceAliasName, _sourceMappingAuth);
	  			
	  			IUser existingTargetUser = getUserBy(targetUser, _targetMappingAuth);
	  			
	  			/* @Kiewit, if user account does not match try it with leading 000 with meet 8 character length
	  			if (existingTargetUser == null)  
	  			{
	  				logger.debug("performDeleteAndAdd() - getUseBy try fixStringReturn handler for target user: " + targetUser);
	  				existingTargetUser = getUserBy( fixStringReturn (targetUser), _targetMappingAuth);  
	  			}*/
	  			//when there is valid tagetUser - LDAP\AD in our case
	  			
	  			try{
		  			
		  			if (existingSourceUser != null && existingTargetUser != null && commitTrue)
		  			{
		  				existingSourceUser.deleteNow();
		  			}
		  			if (existingTargetUser != null)
		  			{
		  				IUserAliases existingTargetAlias = existingTargetUser.getAliases();
		  				logger.debug("performDeleteAndAdd() " + _sourceMappingAuth +  ":" + sourceAliasNameStripped);
		  				
		  				existingTargetAlias.addNew(_sourceMappingAuth +  ":" + sourceAliasName, false);
		  				
		  				if (commitTrue)
		  				{
		  					queryAliasIStor.commit(userQuery);
		  				}
		  				logger.debug("performDeleteAndAdd() Matching Successfully: [" + sourceAliasName + "] to [" + existingTargetUser.getTitle() + "]");
		  			}

	  			}catch (SDKException err) {
	  		        logger.debug("performDeleteAndAdd() - error = " + err.getDetailMessage()
	  		        + err.getExceptionCode() + "\n" + err.getStackTrace());
	  		      writeExceptionFileName("performDeleteAndAdd() committed failed: " + targetUser + " <-" + sourceAliasName );
	  		      //throw new RuntimeException(err.getMessage());
	  		      
	  			}
	  		}
	  		else
	  		{
	  			writeExceptionFileName("LDAP search failed performDeleteAndAdd ," + sourceAliasNameStripped);
	  			logger.info("Found no target ID to match by LDAP search [" + sourceAliasName + "]"); //?? log to trace
	  		}
	  		
		}
	}
	/*@
	 * performReassign()
	 */
private void performReassign() throws SDKException, IOException
{
	boolean commitTrue = _runInProdMode.equalsIgnoreCase("true");
	
	for(Iterator itr = userAliasContainerItems.keySet().iterator(); itr.hasNext();){
		String sourceAliasName = (String)itr.next(); //get the source login
  		String sourceAliasNameStripped = sourceAliasName.substring( sourceAliasName.indexOf("/")+1 , sourceAliasName.length() );  //strip out system name BWx~000/
  		String targetUser = queryLDAP(sourceAliasNameStripped, true); // query LDAP server to get full name by employeeID = sapLoginID
  		if (  targetUser.length()>2 )
  		{
  			logger.debug("performReassign() query LDAP Account to get target CMS user " + targetUser  + " with "+  sourceAliasName);
  			IUser existingSourceUser = getUserBy(sourceAliasNameStripped, _sourceMappingAuth);
  			IUser existingTargetUser = getUserBy(targetUser, _targetMappingAuth);
  			//when there is valid tagetUser - LDAP\AD in our case
  			
  			if (existingSourceUser != null && existingTargetUser != null)
	  		{
	  			try{
	  				String sourceAliasID  =  getAliasIDBy(existingSourceUser, _sourceMappingAuth);
	  				IUserAliases existingTargetAlias = existingTargetUser.getAliases();
	  				logger.debug("performReassign() " + _sourceMappingAuth +  ":" + sourceAliasNameStripped);
	  				
	  				existingTargetAlias.addExisting(_sourceMappingAuth +  ":" + sourceAliasName, _sourceMappingAuth +  ":" + sourceAliasID,false);
	  				logger.debug("performReassign() commits");
	  				
	  				if (commitTrue) queryAliasIStor.commit(userQuery);
	  				
	  			
	  			}catch (SDKException err) {
	  		        logger.debug("performReassign() - error = " + err.getDetailMessage());
	  		      throw new RuntimeException(err.getMessage());
	  			}
	  		}
  		}
  		else
  		{
  			logger.info("Found no target ID to match by search [" + sourceAliasName + "]"); //?? log to trace
  		}
  		
	}
}
	/*@
	 * Perform Matching Rule
	 */
private void performMatchSAPtoWinAD() throws SDKException, IOException
{
	
	IUserAliases existingAlias = null; 
  	for(Iterator itr = userAliasContainerItems.keySet().iterator(); itr.hasNext();){
			
  		
  		String sourceAliasName = (String)itr.next(); //get the source login
  		String sourceAliasNameStripped = sourceAliasName.substring( sourceAliasName.indexOf("/")+1 , sourceAliasName.length() );  //strip out system name BWx~000/
  		String targetUser = queryLDAP(sourceAliasNameStripped, true); // query LDAP server to get full name by employeeID = sapLoginID
  		
  	
  		if ( !sourceAliasNameStripped.equals("2") &&  targetUser.length()>2 )
  		{
  			logger.debug("performMatchSAPtoWinAD() sapLoginID: " + sourceAliasNameStripped + " targetUser: " + targetUser);

  			IUser existingUser = getUserBy(targetUser, _targetMappingAuth);
  			//when there is valid corresponding user
  			if (existingUser != null)
  			{
  				existingAlias = existingUser.getAliases();
  			
	  			//String targetAliasID  =  _tagetMappingAuth + ":"+ getAliasIDBy(sapLoginID, _tagetMappingAuth ); // search to get existing Alias to map into
	  			String targetAliasID  =  getAliasIDBy(existingUser, _targetMappingAuth);
	  			if (targetAliasID==null)
	  			{
	  				logger.error("performMatchSAPtoWinAD() - getAliasIDBy return Null for " + existingUser + ":" + _targetMappingAuth);
	  			}
	  			targetAliasID = _targetMappingAuth + ":" + targetAliasID; // search to get existing Alias to map into
	  			
	  			logger.debug("performMatchSAPtoWinAD - adding existing user " + targetUser + " with " +  targetAliasID);		
	  			existingAlias.addExisting(sourceAliasName, targetAliasID, false);
  			}
  			
  		}	
  		else
  		{
  			logger.debug("performMatchSAPtoWinAD - No matching for " + sourceAliasName + " by targetUser " + targetUser);
  		}
  		
  			
  	}
  	try{
  		_infoStore.commit(userQuery);
  		logger.info("Committing perfomMatchSAPtoWinAD Successfully");
  	} catch (SDKException err) {
        logger.error("performMatchSAPtoWinAD error");
    }
  	
  	
}

	/**
	 * @param args
	 * @throws SDKException 
	 * @throws IOException 
	 */
	public static void main(String[] args) {
		java.net.URL LoadRISE_log4j = ClassLoader.getSystemResource("AutoAliasMapping_log4j.properties");
		PropertyConfigurator.configure(LoadRISE_log4j);
		
		logger.info("Starting - in main");
		AutoAliasMapping AutoAliasMappingNow = new AutoAliasMapping();
        try{
        	
        	AutoAliasMappingNow.init(null);
        	
        	//logger.info("Read and assemble file into hashmap...");
        	//AutoAliasMappingNow.readSourceFile();
        	
        	//Search the CMS to find accounts with SAP Aliases without AD in same account
        	AutoAliasMappingNow.searchSAPAliasWOAD();
        	//AutoAliasMappingNow.performMatchSAPtoWinAD();
        	
        	//logger.debug("Calling performDeleteAndAdd()");
        	AutoAliasMappingNow.performDeleteAndAdd();
        	
        	//logger.debug("Calling performReassign()");
        	//AutoAliasMappingNow.performReassign();
        	
        	logger.info("Log off user...");
        	AutoAliasMappingNow.logoff();
        } catch (Exception e1) {
			logger.error("Exception caught in Main:", e1);
		}
		logger.info("Ended");
	}
	@Override
	public void run(IEnterpriseSession Session, IInfoStore InfoStore, String[] args) throws SDKException
	{
		java.net.URL LoadRISE_log4j = ClassLoader.getSystemResource("AutoAliasMapping_log4j.properties");
		PropertyConfigurator.configure(LoadRISE_log4j);
		
		logger.info("Starting - in main");
		AutoAliasMapping AutoAliasMappingNow = new AutoAliasMapping();
        try{
        	AutoAliasMappingNow.init(null);
        	
        	//logger.info("Read and assemble file into hashmap...");
        	//AutoAliasMappingNow.readSourceFile();
        	
        	//Search the CMS to find accounts with SAP Aliases without AD in same account
        	AutoAliasMappingNow.searchSAPAliasWOAD();
        	//AutoAliasMappingNow.performMatchSAPtoWinAD();
        	
        	//logger.debug("Calling performDeleteAndAdd()");
        	AutoAliasMappingNow.performDeleteAndAdd();
        	
        	//logger.debug("Calling performReassign()");
        	//AutoAliasMappingNow.performReassign();
        	
        	logger.info("Log off user...");
        	AutoAliasMappingNow.logoff();
        } catch (Exception e1) {
			logger.error("Exception caught in Main:", e1);
		}
		logger.info("Ended");
	}

}
