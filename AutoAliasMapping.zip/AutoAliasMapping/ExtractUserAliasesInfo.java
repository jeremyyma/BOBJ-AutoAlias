/**
 * @author Jeremy.Ma@sap.com 7/26/2012
 * The purpose of this batch process extra user's alias mapping into a txt\tab limited format
 * 
 * Source is a tab delimited file format consist of these fields:
 * SI_NAME; SI_EMAIL_ADDRESS; SI_USERFULLNAME; secSecurity - this incl secEnterprise, secSAPR3, secWinAD, and secLDAP.  
 * For each additional attribute of the same type, it will be divided by ; semi colon.
 * 
 */
package com.sap.businessobjects.jeremyma;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.framework.CrystalEnterprise;
import com.crystaldecisions.sdk.framework.IEnterpriseSession;
import com.crystaldecisions.sdk.framework.ISessionMgr;
import com.crystaldecisions.sdk.occa.infostore.IInfoObjects;
import com.crystaldecisions.sdk.occa.infostore.IInfoStore;
import com.crystaldecisions.sdk.plugin.desktop.program.IProgramBase;
import com.crystaldecisions.sdk.plugin.desktop.user.IUser;
import com.crystaldecisions.sdk.plugin.desktop.user.IUserAlias;
import com.crystaldecisions.sdk.plugin.desktop.user.IUserAliases;

public class ExtractUserAliasesInfo implements IProgramBase
{
	static Logger logger = Logger.getLogger(ExtractUserAliasesInfo.class.getName());
	
	private static IInfoStore _infoStore = null;
	private static IInfoStore queryAliasIStor = null;
	private IEnterpriseSession eSession;
	static String strUserGroupList[];
	static int intUserGroupIDList[];
	static BufferedReader inputFile;
	static BufferedWriter writeFile;  //record action record alias assign
	static HashMap	userAliasContainerItems = new HashMap();
	IInfoObjects userQuery;

	// runtime CMS information variables from ExtractUserAliasesInfo.properties file
	private String _cmsHost, _cmsUser, _cmsPassword, _cmsAuthType;
	private String _destinationFileName, _cmsSearchString, _appendToDesFileTrue;
	

	void init(IInfoStore infoStore) throws Exception {
		
		logger.info("ExtractUserAliasesInfo code: 07/26/2012");
		
		InputStream propsFile = ClassLoader.getSystemResourceAsStream("ExtractUserAliases.properties");
		Properties props = new Properties(); //runtime properties
		try {
			props.load(propsFile);
		} catch (IOException io) {
			logger.error("error loading the ExtractUserAliases.properities file!! ",
					io);
			throw io;
		}	
		/**
		 * Load the CMS variables from the property file
		 */
		
		_cmsHost = props.getProperty("cmsHost");
		if (_cmsHost == null) {
			logger.error("Property 'cmsHost' not specified!");
			throw new Exception("Property 'cmsHost' not specified!");
		}

		_cmsUser = props.getProperty("cmsUser");
		if (_cmsUser == null) {
			logger.error("Property 'cmsUser' not specified!");
			throw new Exception("Property 'cmsUser' not specified!");
		}

		_cmsPassword = props.getProperty("cmsPassword");
		if (_cmsPassword == null) {
			logger.error("Property 'cmsPassword' not specified!");
			throw new Exception("Property 'cmsPassword' not specified!");
		}

		_cmsAuthType = props.getProperty("cmsAuthType");
		if (_cmsAuthType == null) {
			logger.error("Property 'cmsAuthType' not specified!");
			throw new Exception("Property 'cmsAuthType' not specified!");
		}
		
		_destinationFileName = props.getProperty("destinationFileName");
		if (_destinationFileName == null) {
			logger.error("Property 'destinationFileName' not specified!");
			throw new Exception("Property 'destinationFileName' not specified!");
		}
		
		_cmsSearchString = props.getProperty("cmsSearchString");
		if (_cmsSearchString == null) {
			logger.error("Property 'cmsSearchString' not specified!");
			throw new Exception("Property 'cmsSearchString' not specified!");
		}
		
		_appendToDesFileTrue = props.getProperty("appendToDesFileTrue");
		if (_appendToDesFileTrue == null) {
			_appendToDesFileTrue = "true";
		}
		
//	   	write file
		writeFile = writeLogFile(_destinationFileName);
	   
		if (infoStore == null) {
			// create a new session to the CMS database
			logger.info("Logging into the CMS database");
			login();
		}
		else {
			// There is already a valid CMS session
			ExtractUserAliasesInfo._infoStore = infoStore;
		}
		
		
	}
    /**
     * Method to write log  file
     */
		public  BufferedWriter writeLogFile(String outputFileName){
			  String fName = outputFileName;	
			  BufferedWriter myOutput = null;
			  boolean appendFile = _appendToDesFileTrue.equalsIgnoreCase("true");
			  try{
				  FileWriter fws = new FileWriter(fName,appendFile);
				  myOutput = new BufferedWriter(fws);
			  }catch (IOException e) {
		
		         e.printStackTrace();
		     }
			  return myOutput;
		}
	/**
	 * open LDAP Server connects
	 */
	

	public static String getDateTime(int minusHours) 
	{	
		minusHours = minusHours*(-1);

		String dt = "";  // Start date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
		Calendar c = Calendar.getInstance();
		try{
			c.setTime(c.getTime());
			c.add(Calendar.HOUR, minusHours);  // number of days to add
		}catch (Exception e) {
			logger.error ("Fail at getDateTime");
		}

		dt = sdf.format(c.getTime());  // dt is now the new date
		return dt;
		
	}
	/*
	 * searchSAPAliasWOAD - Generate a worklist by searching For SAP Alias where it contains no Associated target (WinAD) Alias
	 * 
	 */

	void readUserAlias()
	{
				
		IInfoObjects oInfoObjects =null;
		try
		{
			_infoStore = (IInfoStore)eSession .getService("InfoStore");

			logger.debug("readUserAlias() - querying CMS for worklist " +  _cmsSearchString);
			oInfoObjects = _infoStore.query(_cmsSearchString);
			
			writeFile.append ( 	"SI_NAME \t  SI_EMAIL_ADDRESS \t  SI_USERFULLNAME \t secEnterprise \t" +
				      			" secSAPR3 \t secWinAD  \t secLDAP+ \n"  ) ;
				
			//for each user in the infoStore
	        for(Iterator iuser = oInfoObjects.iterator() ; iuser.hasNext() ; ) {  
			    boolean hasTarget = false;
			    boolean hasSource = false;
	        	IUser oUser = (IUser) iuser.next();
	            IUserAliases userAliases = oUser.getAliases();
	 
			      //retrieve the user and aliases
	
			      IUserAliases oAliases = oUser.getAliases();
			      boolean aliasExists = false;
			      Iterator iter = oAliases.iterator();
			      String SI_NAME = oUser.getTitle(); //SI_NAME
			      String SI_EMAIL_ADDRESS = oUser.getEmailAddress(); //SI_EMAIL_ADDRESS
			      String SI_USERFULLNAME = oUser.getFullName();
			      String secEnt = "";
			      String secSAPR3 = "";
			      String secWinAD = "";
			      String secLDAP = "";
	
			      String[] storage = new String[3]; //Storing user Alias details
			      String tempAliasName = ""; // storing Alias name exmaple BW7~800/CAMPMAN
			      int tempAliasID = 0; // storing Alias unique identifier 
			      
			      //loop for each alias per user
			      for (Iterator ialias = userAliases.iterator() ; ialias.hasNext(); ) {
	                  IUserAlias userAlias = (IUserAlias) ialias.next(); 
	                  String authentication;
	
	                  authentication = userAlias.getAuthentication();
	                  if ( authentication.equals("secEnterprise") )
	                  {
	                	  secEnt = userAlias.getName();                	  
	                  } 

	                  else if (authentication.equals("secSAPR3")) 
	                  {
	                	  secSAPR3 = userAlias.getName()  + ";" + secSAPR3;
	                  }
	                  else if (authentication.equals("secWinAD")) 
	                  {
	                	  secWinAD = secWinAD + "; " + userAlias.getName();
	                  }
	                  else if (authentication.equals("secLDAP")) 
	                  {
	                	  secLDAP = userAlias.getName()  + ";" + secLDAP;
	                  }
			      }
			      
			      writeFile.append ( SI_NAME + "\t" + SI_EMAIL_ADDRESS + "\t"  + SI_USERFULLNAME + "\t" + secEnt+ "\t"
			      +  secSAPR3 + "\t" + secWinAD  + "\t" + secLDAP+ "\n"  ) ;
			     
	
			 }
		}
		catch (Exception e) {
			logger.error ("Fail at readUserAlias");
		}
		
	}
	

	
	private void login() throws Exception {
		/**
		 * Creates a session with the CMS and retrieve the InfoStore
		 */
		try {
			ISessionMgr mySessionMgr = CrystalEnterprise.getSessionMgr();
			eSession = mySessionMgr.logon(_cmsUser, _cmsPassword, _cmsHost, _cmsAuthType);
			
			if (eSession == null) {
				logger.error("Failed to logon to CMS - The session is null");
				throw new Exception(
						"Failed to logon to CMS - The session is null");
			} else {
				logger.info("Opened CMS session to - Host: " + _cmsHost
						+ " user: " + _cmsUser + " password: " + _cmsPassword
						+ " authType: " + _cmsAuthType);
			}

			_infoStore = (IInfoStore) eSession.getService("InfoStore");
		
		} catch (SDKException sdkEx) {
			logger.error("Failed to connect to CMS", sdkEx);
			throw new Exception("Failed to connect to CMS", sdkEx);
		}
	}
	/**
	 * Log off BOE and nullify the infostore
	 * @throws Exception
	 */
	private void logoff() throws Exception {
		_infoStore = null;
		eSession.logoff();	// CMS sessiong logout
		//??inputFile.close();	// Matching source file close
		writeFile.close();
	}

	/**
	 * @param args
	 * @throws SDKException 
	 * @throws IOException 
	 */
	public static void main(String[] args) {
		java.net.URL Extract_log4j = ClassLoader.getSystemResource("ExtractUserAliasesInfo_log4j.properties");
		PropertyConfigurator.configure(Extract_log4j);
		
		logger.info("Starting - in main");
		ExtractUserAliasesInfo ExtractUserAliasesInfoNow = new ExtractUserAliasesInfo();
        try{
        	
        	ExtractUserAliasesInfoNow.init(null);
                	
        	//Search the CMS to find accounts with SAP Aliases without AD in same account
        	ExtractUserAliasesInfoNow.readUserAlias();

        	writeFile.flush();
        	
        	logger.info("Log off user...");
        	ExtractUserAliasesInfoNow.logoff();
        } catch (Exception e1) {
			logger.error("Exception caught in Main:", e1);
		}
		logger.info("Ended");
	}
	@Override
	public void run(IEnterpriseSession Session, IInfoStore InfoStore, String[] args) throws SDKException
	{
		java.net.URL Extract_log4j = ClassLoader.getSystemResource("ExtractUserAliasesInfo_log4j.properties");
		PropertyConfigurator.configure(Extract_log4j);
		
		logger.info("Starting - in main");
		ExtractUserAliasesInfo ExtractUserAliasesInfoNow = new ExtractUserAliasesInfo();
        try{
        	ExtractUserAliasesInfoNow.init(null);
        	
        	ExtractUserAliasesInfoNow.readUserAlias();
        	
        	
        	logger.info("Log off user...");
        	ExtractUserAliasesInfoNow.logoff();
        } catch (Exception e1) {
			logger.error("Exception caught in Main:", e1);
		}
		logger.info("Ended");
	}

}
